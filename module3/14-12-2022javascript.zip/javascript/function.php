<script>
function test()
{
    var name="Hi i am Brijesh";
    document.write(name);
}
test();

</script>