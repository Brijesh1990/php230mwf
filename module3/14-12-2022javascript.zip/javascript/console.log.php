<script>
var a=10;
var bb=5;
if(a>bb)
{
    // document.write("a is greter than b");
    console.log("a is grter than b");
}

else 

{
    console.log("a is less than b");
}

</script>
