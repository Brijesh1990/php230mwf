<script>
var a=10;
var b=20;
var c=a+b;
//alert('Additions of numbers is :'+c)
document.write("Additions of numbers is :",c);
</script>