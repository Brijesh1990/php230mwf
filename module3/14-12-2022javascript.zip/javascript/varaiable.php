<script>
// var a=10;
// var b=20;
// var c=a+b;

// let a=10;
// let b=20;
// let c=a+b;

const a=10;
const b=20;
const c=a+b;
//alert('Additions of numbers is :'+c)
document.write("Additions of numbers is :",c);

</script>