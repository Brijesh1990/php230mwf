<script>
var a=10;
var b=5;
if(a>b)
{
    document.write("a is greter than b");
}

else 

{
    document.write("a is less than b");
}

</script>
