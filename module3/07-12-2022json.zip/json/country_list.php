<?php

$country=array("ind"=>"india","usa"=>"united state of america","uk"=>"United kingdom","can"=>"canada","uae"=>"united arab emirates","kuw"=>"kuwait");
echo json_encode($country);
?>