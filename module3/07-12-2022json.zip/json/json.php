<!-- 
what is json ?
json stands for javascript object notation
json is used to create a webservices in php

what is webservices ?
  get data or fetch data from any server or url there we used websirvices.
  
json is used to convert any array into no readable formate or readable formate.
  json_encode();
  json_decode();
  
 -->