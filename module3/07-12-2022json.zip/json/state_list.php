<?php

$st=array("guj"=>"gujrat","up"=>"uttar pradesh","mp"=>"madhya pradesh","mh"=>"Maharstra");
echo json_encode($st);
// http://country.io/names.json
?>