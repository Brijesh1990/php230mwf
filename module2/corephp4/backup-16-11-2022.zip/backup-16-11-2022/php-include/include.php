<?php
$n=$_POST["num"]; 
if($n%2==0)
{
    echo "<h1 align='center'>Numbers is Even</h1>";
}
else 
{
    echo "<h1 align='center'>Numbers is Odd</h1>";

}

?>