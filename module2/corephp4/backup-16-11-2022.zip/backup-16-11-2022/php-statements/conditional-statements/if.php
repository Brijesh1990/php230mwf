<?php
/* 
if : if is executed when condition is true 
   syntax : if(condition)
            {
                statements;
            }

*/

$a=30;
$b=20;
if($a>$b)
{
    echo "a is greter than b";
}
?>