<?php
/* 
if else: if is executed when condition is true while condition is false else is executed 
   syntax : if(condition)
            {
                statements;
            }

*/

$a=30;
$b=80;
if($a>$b)
{
    echo "a is greter than b";
}
else 
{
    echo "a is less than b";
}
?>