<?php 
for($i=1;$i<=100;$i++)
{
    if($i==50 || $i==60)
    {
        continue;
    }
    echo $i."<br>";
}


?>