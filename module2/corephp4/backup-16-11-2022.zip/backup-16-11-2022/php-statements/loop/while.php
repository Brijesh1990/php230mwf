<?php 
// while : while is executed when condition is true

//   while(condition)
//   {
//     statements;
//     increment/decerements;
//   }

  $i=0;
  while($i<=10)
  {
    echo $i."<br>";
    $i++;
  }
?>