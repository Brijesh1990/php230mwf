<!-- 
loop : where numbers of iteration repeat again and again there we used loop
          or
       numbers of things repeat gain and again there we used loop   
 -->