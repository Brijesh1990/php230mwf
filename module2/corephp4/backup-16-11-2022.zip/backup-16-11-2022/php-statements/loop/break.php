<?php 
for($i=1;$i<=100;$i++)
{
    if($i==51)
    {
        break;
    }
    echo $i."<br>";
}


?>