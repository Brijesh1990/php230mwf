<?php 
// foreach : foreach is used to convert any array into value
$arr=array("ayush","ayushi","komal","miten","kishan","brijesh","mitesh");
//print_r($arr);
foreach($arr as $value)
{
   echo "Name is :".$value."<br>";
}

?>