<?php 
// do while :do will excecuted once time while condition is true or false  after check while is executed when condition is true.
// do
// {
// statements;
// increment/decerements;
//   }
// while(condition)

  $i=0;
  do
  {
    echo $i."<br>";
    $i++;
  }
  while($i<=10)
?>