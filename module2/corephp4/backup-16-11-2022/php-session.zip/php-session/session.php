<!-- 
what is session ?
session is a variable where we stored a temprorary information about data there we used session.
session will used to stored temporary information one page to another page
session stored data on server side.
session exprired by default in 24 minutes or 1440 seconds. 

  how to start session :
  a) session_start(); 
  how to retrived data in session 
  b)$_SESSION["id"];
  how to unset data from session or remove data from session
  c)unset($_SESSION["id"]);  
  how to sdestroy a session
  d)session_destroy();

 -->