<?php 
class A 
{
    public function A()
    {
       $name="My nam is Kishan";
       echo $name;
    }
}
$obj=new A;

?>