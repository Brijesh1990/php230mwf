<?php 
require_once("controller/controller.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Page Title</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
    <script src='main.js'></script>
</head>
<body>
    <center>
     <form method="post" action="">

        Enter Your Name :<input type="text" name="nm" placeholder="Enter Name *" required>
        <br><br>
        <input type="submit" name="sub" value="check">
     </form>

    </center>
    
</body>
</html>