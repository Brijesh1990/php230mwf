<?php 
/* 
constructor : A constructor is a same name of the class when we called the object of class constructor automatically called.

types of constructor 

  a) user defined constructor
  b) parameterized constructor 
  c) default constructor

*/


?>