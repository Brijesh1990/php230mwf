<?php 
/*Polymorphism : A polymorphism is used many form to create one applications there we used polymorphism 

types of polymorphism :
 a) method overloading
 b) method overriding

 

*/ 


?>