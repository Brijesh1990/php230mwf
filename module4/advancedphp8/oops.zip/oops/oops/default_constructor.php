<?php 
class A 
{
    public function __construct()
    {
       $name="My nam is Kishan";
       echo $name;
    }
}
$obj=new A;

?>