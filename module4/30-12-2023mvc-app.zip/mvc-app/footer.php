
<div class="container-fluid bg-dark footer p-3">
    <div class="row">
        <div class="col-md-8">
            <div class="row">
                <div class="col-md-3">
                    <ul class="footer-navbar">
                        <li><a href="productsdetails.html"><h6>ABOUT</h6></a></li>
                        <li><a href="productsdetails.html">Contact us</a></li>
                        <li><a href="productsdetails.html">About us</a></li>
                        <li><a href="productsdetails.html">Careers</a></li>
                        <li><a href="productsdetails.html">Komal e-commerce stories</a></li>
                        <li><a href="productsdetails.html">Press</a></li>
                        <li><a href="productsdetails.html">Komal e-commerce wholesales</a></li>
                        <li><a href="productsdetails.html">Corperate Informations</a></li>
    
                    </ul>
                </div>
                <div class="col-md-3">
                    <ul class="footer-navbar">
                        <li><a href="productsdetails.html"><h6>HELP</h6></a></li>
                        <li><a href="productsdetails.html">Payments</a></li>
                        <li><a href="productsdetails.html">Shipping</a></li>
                        <li><a href="productsdetails.html">Cancelations & returns</a></li>
                        <li><a href="productsdetails.html">FAQ</a></li>
                        <li><a href="productsdetails.html">Report infrigments</a></li>
                    
                    </ul>
                </div>
    
                <div class="col-md-3">
                    <ul class="footer-navbar">
                        <li><a href="productsdetails.html"><h6>POLICY</h6></a></li>
                        <li><a href="productsdetails.html">Return policy</a></li>
                        <li><a href="productsdetails.html">Terms of uses</a></li>
                        <li><a href="productsdetails.html">Security</a></li>
                        <li><a href="productsdetails.html">Privacy</a></li>
                        <li><a href="productsdetails.html">Sitemap</a></li>
                        <li><a href="productsdetails.html">EPR complences</a></li>
                 
                    </ul>
                </div>
    
                <div class="col-md-3 footer-border">
                    <ul class="footer-navbar">
                        <li><a href="productsdetails.html"><h6>SOCIAL</h6></a></li>
                        <li><a href="productsdetails.html">Facebook</a></li>
                        <li><a href="productsdetails.html">Instagram</a></li>
                        <li><a href="productsdetails.html">Twitter</a></li>
                        
                    </ul>
                </div>
            </div>
        </div>
    
        <div class="col-md-2 text-white p-3">
            <p><b>Mail Us:</b>
                <br>
                Komal e-commerce Internet Private Limited,
                Buildings Alyssa, Begonia &
                Clove Embassy Tech Village,
                Outer Ring Road, Devarabeesanahalli Village,
                Bengaluru, 560103,
                Karnataka, India
                </p>
        </div>
    
        <div class="col-md-2 text-white p-3">
            <p><b> Registered Office Address:</b>
                <br>
             
                Komal e-commerce Internet Private Limited,
                Buildings Alyssa, Begonia &
                Clove Embassy Tech Village,
                Outer Ring Road, Devarabeesanahalli Village,
                Bengaluru, 560103,
                Karnataka, India
                CIN : U51109KA2012PTC066107            
                Telephone: 044-45614700
                
                </p>
        </div>
        <div class="row">
            <div class="col-md-8 text-white p-5">
             <i class="bi bi-gift"> &nbsp;Gift voucher</i> 
             <i class="bi bi-gift"> &nbsp;Gift voucher</i> 
             <i class="bi bi-gift"> &nbsp;Gift voucher</i> 
             <i class="bi bi-gift"> &nbsp;Gift voucher</i> 
           
             <i class="bi bi-gift"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Copyright 202022 all right reserved</i> 
            </div>
            <div class="col-md-4 p-5">
                <img src="images/payments/payment.svg" class="img-fluid">
            </div>
        </div>
    
    </div>



    </div>    