
<!-- content start here -->
<div class="container content mt-5">
    <div class="card">
        <div class="card-header">View Cart</div>
        <div class="card-body">
            <center>
            <img src="<?php echo $baseurl;?>images/cart.webp" class="img-fluid" style="width: 30%">
            <br><br>
            <h5 class="text-center">Missing Cart items?</h5> 
            <p class="text-center">Login to see the items you added previously</p>
            <button type="button" class="btn btn-lg btn-danger">Login</button>
        </center>
        </div>
    </div>



</div>
