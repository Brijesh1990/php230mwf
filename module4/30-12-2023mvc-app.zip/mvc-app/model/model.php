<?php
class model 
{
    public function __construct()
    {
        // database connection

    }
} 
?>