

<!-- content start here -->
<div class="container-fluid content mt-5">
<div class="row">  
<div class="col-md-9">
 <a href=""> Home/Contact us >> </a>   
<div class="card mt-5">
<div class="card-header bg-dark text-white"><h4 class="">Contact with Us  <button type="button" class="btn btn-danger btn-sm float-end text-white ">view More >></button></h4></div>

<div class="card-body">
<div class="row">
<div class="col-md-6 shadow">
    <p><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.7017514972595!2d77.68951691423212!3d12.926880719357!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae13a416174f49%3A0x6eea803364bb0189!2sFlipkart%20Internet%20Private%20Limited!5e0!3m2!1sen!2sin!4v1666346670780!5m2!1sen!2sin" width="90%" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe> </p>
    <p><b>Our Address:</b>
        <br>
        Komal e-commerce Internet Private Limited,
        Buildings Alyssa, Begonia &
        Clove Embassy Tech Village,
        Outer Ring Road, Devarabeesanahalli Village,
        Bengaluru, 560103,
        Karnataka, India
        </p>

       
</div>
<div class="col-md-5">
    <div class="form-group mt-2 col-md-12 mx-auto">
        <input type="text" name="name" placeholder="Name *" required class="form-control">
      </div>
    <div class="form-group mt-2 col-md-12 mx-auto">
        <input type="text" name="email" placeholder="Email *" required class="form-control">
      </div>
      
      <div class="form-group mt-2 col-md-12 mx-auto">
        <input type="text" name="fname" placeholder="FirstName *" required class="form-control">
      </div>

      <div class="form-group mt-2 col-md-12 mx-auto">
        <input type="text" name="lname" placeholder="LastName *" required class="form-control">
      </div>

      <div class="form-group mt-2 col-md-12 mx-auto">
        <input type="text" name="mobile" placeholder="Mobile *" required class="form-control">
      </div>

      <div class="form-group mt-2 col-md-12 mx-auto">
        <textarea  name="message" placeholder="message *" required class="form-control"></textarea>
      </div>
      <div class="form-group mt-2 col-md-12 mx-auto">
        <input type="submit" name="reg" class="btn btn-lg btn-info" value="Send">
        <input type="reset" name="reset" class="btn btn-lg btn-danger" value="Reset">
      
      </div>

</div>

</div>
</div>
</div>
</div> 

<div class="col-md-3 mt-5">
<img src="<?php echo $baseurl;?>images/adv/adv.webp" class="img-fluid">
</div>
</div> 
</div>
