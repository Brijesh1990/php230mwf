<?php 
$mainurl="http://localhost/php230mwf/module4/mvc-app/";
$baseurl="http://localhost/php230mwf/module4/mvc-app/assets/";
?>
<!DOCTYPE html>
<html>
<head>
<meta charset='utf-8'>
<meta http-equiv='X-UA-Compatible' content='IE=edge'>
<title>Online Komal e-commerce shop for Kids items | Mens Items | Womens items contact us on 9998003879</title>
<meta name='viewport' content='width=device-width, initial-scale=1'>
<!-- css file -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

<link href="<?php echo $baseurl;?>css/style.css" rel="stylesheet">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
<!-- script file -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>

</head>
<body>
<!-- header start here -->
<div class="container p-5 header">
<div class="row">
<div class="col-md-4">
<b>Call Us :<i class="bi bi-phone"></i>(+91)-9998003879</b>
</div>
<div class="col-md-6">
<b><input type="text" name="search" placeholder="Search your products here!!" class="form-control"></b>
</div>
<div class="col-md-2">
<i class="bi bi-facebook"></i>
<i class="bi bi-instagram"></i>
<i class="bi bi-twitter"></i>
<i class="bi bi-youtube"></i>
</div>
</div>
</div>


</body>
</html>