<!-- content start here -->
<div class="container-fluid content mt-5">
<div class="col-md-9 p-4">
<a href="<?php echo $mainurl;?>"><img src="<?php echo $baseurl;?>images/404.gif"></a>
</div>
</div>
