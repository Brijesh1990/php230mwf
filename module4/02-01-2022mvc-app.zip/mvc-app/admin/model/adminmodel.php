<?php 
class adminmodel
{
    public function __construct()
    {
        // database connections
        
    }
}
?>