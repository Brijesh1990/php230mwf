<?php 
require_once("controller/admincontroller.php");
?>