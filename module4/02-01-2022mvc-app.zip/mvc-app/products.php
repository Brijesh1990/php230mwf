

<!-- content start here -->
<div class="container-fluid content mt-5">
<div class="row">  
<div class="col-md-9">
<div class="card">
<div class="card-header bg-dark text-white"><h4 class="">Womens Items <button type="button" class="btn btn-danger btn-sm float-end text-white ">view More >></button></h4></div>
<div class="card-body">
<div class="row">
<div class="col-md-4 shadow">
<img src="<?php echo $baseurl;?>images/womens/1.webp" class="img-fluid" style="width: 100%; height: 300px">
<p class="text-center mt-2">Womens fancy kurtis</p>
<p class="text-center"><b>Rs.3520 <del>Rs.4530</del></b></p>
<p class="text-center"><a href="<?php echo $mainurl;?>product-details" class="btn btn-sm btn-danger">More details >></a></p>
</div>

<div class="col-md-4 shadow">
<img src="<?php echo $baseurl;?>images/womens/2.webp" class="img-fluid" style="width: 100%; height: 300px">
<p class="text-center mt-2">Womens fancy kurtis</p>
<p class="text-center"><b>Rs.3520 <del>Rs.4530</del></b></p>
<p class="text-center"><a href="<?php echo $mainurl;?>product-details" class="btn btn-sm btn-danger">More details >></a></p>
</div>
<div class="col-md-4 shadow">
<img src="<?php echo $baseurl;?>images/womens/3.webp" class="img-fluid" style="width: 100%; height: 300px">
<p class="text-center mt-2">Womens fancy kurtis</p>
<p class="text-center"><b>Rs.3520 <del>Rs.4530</del></b></p>
<p class="text-center"><a href="<?php echo $mainurl;?>product-details" class="btn btn-sm btn-danger">More details >></a></p>
</div>
</div>
</div>
</div>
</div> 

<div class="col-md-3">
<img src="<?php echo $baseurl;?>images/adv/adv.webp" class="img-fluid">
</div>
</div> 


<!-- womens products -->
<div class="row mt-5">  
<div class="col-md-12">
<div class="card">
<div class="card-header bg-dark text-white"><h4 class="">Womens Items <button type="button" class="btn btn-danger btn-sm float-end text-white ">view More >></button></h4></div>
<div class="card-body">
<div class="row">
<div class="col-md-3 shadow">
<img src="<?php echo $baseurl;?>images/womens/5.webp" class="img-fluid" style="width: 100%; height: 300px">
<p class="text-center mt-2">Womens fancy kurtis</p>
<p class="text-center"><b>Rs.3520 <del>Rs.4530</del></b></p>
<p class="text-center"><a href="<?php echo $mainurl;?>product-details" class="btn btn-sm btn-danger">More details >></a></p>
</div>

<div class="col-md-3 shadow">
<img src="<?php echo $baseurl;?>images/womens/6.webp" class="img-fluid" style="width: 100%; height: 300px">
<p class="text-center mt-2">Womens fancy kurtis</p>
<p class="text-center"><b>Rs.3520 <del>Rs.4530</del></b></p>
<p class="text-center"><a href="<?php echo $mainurl;?>product-details" class="btn btn-sm btn-danger">More details >></a></p>
</div>
<div class="col-md-3 shadow">
<img src="<?php echo $baseurl;?>images/womens/7.webp" class="img-fluid" style="width: 100%; height: 300px">
<p class="text-center mt-2">Womens fancy kurtis</p>
<p class="text-center"><b>Rs.3520 <del>Rs.4530</del></b></p>
<p class="text-center"><a href="<?php echo $mainurl;?>product-details" class="btn btn-sm btn-danger">More details >></a></p>
</div>
<div class="col-md-3 shadow">
<img src="<?php echo $baseurl;?>images/womens/8.webp" class="img-fluid" style="width: 100%; height: 300px">
<p class="text-center mt-2">Womens fancy kurtis</p>
<p class="text-center"><b>Rs.3520 <del>Rs.4530</del></b></p>
<p class="text-center"><a href="<?php echo $mainurl;?>product-details" class="btn btn-sm btn-danger">More details >></a></p>
</div>

</div>
</div>
</div>
</div> 



<!-- mens products -->
<div class="row mt-5">  
<div class="col-md-12">
<div class="card">
<div class="card-header bg-dark text-white"><h4 class="">Men's Items <button type="button" class="btn btn-danger btn-sm float-end text-white ">view More >></button></h4></div>
<div class="card-body">
<div class="row">
<div class="col-md-3 shadow">
<img src="<?php echo $baseurl;?>images/mens/6.webp" class="img-fluid" style="width: 100%; height: 300px">
<p class="text-center mt-2">Womens fancy kurtis</p>
<p class="text-center"><b>Rs.3520 <del>Rs.4530</del></b></p>
<p class="text-center"><a href="<?php echo $mainurl;?>product-details" class="btn btn-sm btn-danger">More details >></a></p>
</div>

<div class="col-md-3 shadow">
<img src="<?php echo $baseurl;?>images/mens/7.webp" class="img-fluid" style="width: 100%; height: 300px">
<p class="text-center mt-2">Womens fancy kurtis</p>
<p class="text-center"><b>Rs.3520 <del>Rs.4530</del></b></p>
<p class="text-center"><a href="<?php echo $mainurl;?>product-details" class="btn btn-sm btn-danger">More details >></a></p>
</div>
<div class="col-md-3 shadow">
<img src="<?php echo $baseurl;?>images/mens/8.webp" class="img-fluid" style="width: 100%; height: 300px">
<p class="text-center mt-2">Womens fancy kurtis</p>
<p class="text-center"><b>Rs.3520 <del>Rs.4530</del></b></p>
<p class="text-center"><a href="<?php echo $mainurl;?>product-details" class="btn btn-sm btn-danger">More details >></a></p>
</div>
<div class="col-md-3 shadow">
<img src="<?php echo $baseurl;?>images/mens/5.webp" class="img-fluid" style="width: 100%; height: 300px">
<p class="text-center mt-2">Womens fancy kurtis</p>
<p class="text-center"><b>Rs.3520 <del>Rs.4530</del></b></p>
<p class="text-center"><a href="<?php echo $mainurl;?>product-details" class="btn btn-sm btn-danger">More details >></a></p>
</div>

</div>
</div>
</div>
</div> 



<div class="row mt-5">  
<div class="col-md-12">
<div class="card">
<div class="card-header bg-dark text-white"><h4 class="">Men's Items <button type="button" class="btn btn-danger btn-sm float-end text-white ">view More >></button></h4></div>
<div class="card-body">
<div class="row">
<div class="col-md-3 shadow">
<img src="<?php echo $baseurl;?>images/mens/1.webp" class="img-fluid" style="width: 100%; height: 300px">
<p class="text-center mt-2">Womens fancy kurtis</p>
<p class="text-center"><b>Rs.3520 <del>Rs.4530</del></b></p>
<p class="text-center"><a href="<?php echo $mainurl;?>product-details" class="btn btn-sm btn-danger">More details >></a></p>
</div>

<div class="col-md-3 shadow">
<img src="<?php echo $baseurl;?>images/mens/2.webp" class="img-fluid" style="width: 100%; height: 300px">
<p class="text-center mt-2">Womens fancy kurtis</p>
<p class="text-center"><b>Rs.3520 <del>Rs.4530</del></b></p>
<p class="text-center"><a href="<?php echo $mainurl;?>product-details" class="btn btn-sm btn-danger">More details >></a></p>
</div>
<div class="col-md-3 shadow">
<img src="<?php echo $baseurl;?>images/mens/3.webp" class="img-fluid" style="width: 100%; height: 300px">
<p class="text-center mt-2">Womens fancy kurtis</p>
<p class="text-center"><b>Rs.3520 <del>Rs.4530</del></b></p>
<p class="text-center"><a href="<?php echo $mainurl;?>product-details" class="btn btn-sm btn-danger">More details >></a></p>
</div>
<div class="col-md-3 shadow">
<img src="<?php echo $baseurl;?>images/mens/5.webp" class="img-fluid" style="width: 100%; height: 300px">
<p class="text-center mt-2">Womens fancy kurtis</p>
<p class="text-center"><b>Rs.3520 <del>Rs.4530</del></b></p>
<p class="text-center"><a href="<?php echo $mainurl;?>product-details" class="btn btn-sm btn-danger">More details >></a></p>
</div>

</div>
</div>
</div>
</div> 


<!-- kids products -->
<div class="row mt-5">  
<div class="col-md-12">
<div class="card">
<div class="card-header bg-dark text-white"><h4 class="">Kid's Items <button type="button" class="btn btn-danger btn-sm float-end text-white ">view More >></button></h4></div>
<div class="card-body">
<div class="row">
<div class="col-md-3 shadow">
<img src="<?php echo $baseurl;?>images/kids/1.webp" class="img-fluid" style="width: 100%; height: 300px">
<p class="text-center mt-2">Womens fancy kurtis</p>
<p class="text-center"><b>Rs.3520 <del>Rs.4530</del></b></p>
<p class="text-center"><a href="<?php echo $mainurl;?>product-details" class="btn btn-sm btn-danger">More details >></a></p>
</div>

<div class="col-md-3 shadow">
<img src="<?php echo $baseurl;?>images/kids/2.webp" class="img-fluid" style="width: 100%; height: 300px">
<p class="text-center mt-2">Womens fancy kurtis</p>
<p class="text-center"><b>Rs.3520 <del>Rs.4530</del></b></p>
<p class="text-center"><a href="<?php echo $mainurl;?>product-details" class="btn btn-sm btn-danger">More details >></a></p>
</div>
<div class="col-md-3 shadow">
<img src="<?php echo $baseurl;?>images/kids/3.webp" class="img-fluid" style="width: 100%; height: 300px">
<p class="text-center mt-2">Womens fancy kurtis</p>
<p class="text-center"><b>Rs.3520 <del>Rs.4530</del></b></p>
<p class="text-center"><a href="<?php echo $mainurl;?>product-details" class="btn btn-sm btn-danger">More details >></a></p>
</div>
<div class="col-md-3 shadow">
<img src="<?php echo $baseurl;?>images/kids/4.webp" class="img-fluid" style="width: 100%; height: 300px">
<p class="text-center mt-2">Womens fancy kurtis</p>
<p class="text-center"><b>Rs.3520 <del>Rs.4530</del></b></p>
<p class="text-center"><a href="<?php echo $mainurl;?>product-details" class="btn btn-sm btn-danger">More details >></a></p>
</div>

</div>
</div>
</div>
</div> 


<div class="row mt-5">  
<div class="col-md-12">
<div class="card">
<div class="card-header bg-dark text-white"><h4 class="">Kid's Items <button type="button" class="btn btn-danger btn-sm float-end text-white ">view More >></button></h4></div>
<div class="card-body">
<div class="row">
<div class="col-md-3 shadow">
<img src="<?php echo $baseurl;?>images/kids/5.webp" class="img-fluid" style="width: 100%; height: 300px">
<p class="text-center mt-2">Womens fancy kurtis</p>
<p class="text-center"><b>Rs.3520 <del>Rs.4530</del></b></p>
<p class="text-center"><a href="<?php echo $mainurl;?>product-details" class="btn btn-sm btn-danger">More details >></a></p>
</div>

<div class="col-md-3 shadow">
<img src="<?php echo $baseurl;?>images/kids/6.webp" class="img-fluid" style="width: 100%; height: 300px">
<p class="text-center mt-2">Womens fancy kurtis</p>
<p class="text-center"><b>Rs.3520 <del>Rs.4530</del></b></p>
<p class="text-center"><a href="<?php echo $mainurl;?>product-details" class="btn btn-sm btn-danger">More details >></a></p>
</div>
<div class="col-md-3 shadow">
<img src="<?php echo $baseurl;?>images/kids/7.webp" class="img-fluid" style="width: 100%; height: 300px">
<p class="text-center mt-2">Womens fancy kurtis</p>
<p class="text-center"><b>Rs.3520 <del>Rs.4530</del></b></p>
<p class="text-center"><a href="<?php echo $mainurl;?>product-details" class="btn btn-sm btn-danger">More details >></a></p>
</div>
<div class="col-md-3 shadow">
<img src="<?php echo $baseurl;?>images/kids/8.webp" class="img-fluid" style="width: 100%; height: 300px">
<p class="text-center mt-2">Womens fancy kurtis</p>
<p class="text-center"><b>Rs.3520 <del>Rs.4530</del></b></p>
<p class="text-center"><a href="<?php echo $mainurl;?>product-details" class="btn btn-sm btn-danger">More details >></a></p>
</div>

</div>
</div>
</div>
</div> 


<div class="container text-justify p-5">
<h3>Komal e-commerce: The One-stop Shopping Destination</h3>
<p align="justify">E-commerce is revolutionizing the way we all shop in India. Why do you want to hop from one store to another in search of the latest phone when you can find it on the Internet in a single click? Not only mobiles. Komal e-commerce houses everything you can possibly imagine, from trending electronics like laptops, tablets, smartphones, and mobile accessories to in-vogue fashion staples like shoes, clothing and lifestyle accessories; from modern furniture like sofa sets, dining tables, and wardrobes to appliances that make your life easy like washing machines, TVs, ACs, mixer grinder juicers and other time-saving kitchen and small appliances; from home furnishings like cushion covers, mattresses and bedsheets to toys and musical instruments, we got them all covered. You name it, and you can stay assured about finding them all here. For those of you with erratic working hours, Komal e-commerce is your best bet. Shop in your PJs, at night or in the wee hours of the morning. This e-commerce never shuts down.</p>
<p align="justify">
What's more, with our year-round shopping festivals and events, our prices are irresistible. We're sure you'll find yourself picking up more than what you had in mind. If you are wondering why you should shop from Komal e-commerce when there are multiple options available to you, well, the below will answer your question.</p>

<h3>Komal e-commerce Plus</h3>
<p align="justify">A world of limitless possibilities awaits you - Komal e-commerce Plus was kickstarted as a loyalty reward programme for all its regular customers at zero subscription fee. All you need is 500 supercoins to be a part of this service. For every 100 rupees spent on Komal e-commerce order, Plus members earns 4 supercoins & non-plus members earn 2 supercoins. Free delivery, early access during sales and shopping festivals, exchange offers and priority customer service are the top benefits to a Komal e-commerce Plus member. In short, earn more when you shop more!</p>
<p align="justify">
What's more, you can even use the Komal e-commerce supercoins for a number of exciting services, like:
An annual Zomato Gold membership
An annual Hotstar Premium membership
6 months Gaana plus subscription
Rupees 550 instant discount on flights on ixigo
Check out https://www.Komal e-commerce.com/plus/all-offers for the entire list. Terms and conditions apply.</p>


<h3>No Cost EMI</h3>

<p align="justify">In an attempt to make high-end products accessible to all, our No Cost EMI plan enables you to shop with us under EMI, without shelling out any processing fee. Applicable on select mobiles, laptops, large and small appliances, furniture, electronics and watches, you can now shop without burning a hole in your pocket. If you've been eyeing a product for a long time, chances are it may be up for a no cost EMI. Take a look ASAP! Terms and conditions apply.</p>

<h3>EMI on Debit Cards</h3>
<p align="justify">Did you know debit card holders account for 79.38 crore in the country, while there are only 3.14 crore credit card holders? After enabling EMI on Credit Cards, in another attempt to make online shopping accessible to everyone, Komal e-commerce introduces EMI on Debit Cards, empowering you to shop confidently with us without having to worry about pauses in monthly cash flow. At present, we have partnered with Axis Bank, HDFC Bank, State Bank of India and ICICI Bank for this facility. More power to all our shoppers! Terms and conditions apply.</p>

<h3>Mobile Exchange Offers</h3>

<p align="justify">Get an instant discount on the phone that you have been eyeing on. Exchange your old mobile for a new one after the Komal e-commerce experts calculate the value of your old phone, provided it is in a working condition without damage to the screen. If a phone is applicable for an exchange offer, you will see the 'Buy with Exchange' option on the product description of the phone. So, be smart, always opt for an exchange wherever possible. Terms and conditions apply.</p>

</div>
</div>
</div>
</div>
</div>
