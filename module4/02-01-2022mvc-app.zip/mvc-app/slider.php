
<!-- slider start here -->
<div class="slider">
<div class="container mt-5 p-3 bg-dark text-white slider-txt">
<h1 class="text-center">50% of on selected Products</h1>
<div class="row">
<div class="col-md-4">    
<div class="bg-danger mt-2 p-3">Mens Products</div>
</div>
<div class="col-md-4">    
<div class="bg-danger mt-2 p-3">Womens Products</div>
</div>
<div class="col-md-4">    
<div class="bg-danger mt-2 p-3">Kids Products</div>
</div>
</div>
</div>
</div>